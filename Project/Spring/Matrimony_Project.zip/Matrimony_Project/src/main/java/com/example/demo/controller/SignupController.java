package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.SignUp;
import com.example.demo.repository.SignUpRepo;
import com.example.demo.service.SignUpService;

@RestController
@CrossOrigin(origins="http://localhost:3000",allowedHeaders="*")
public class SignupController {
@Autowired
SignUpRepo repo;
SignUpService service;
@GetMapping("/get")
public List <SignUp> getALL(){
	return repo.findAll();
}
@PostMapping("/post")
public SignUp create(@RequestBody SignUp stu) {
	return repo.save(stu);
}


}
