package com.example.demo.model;

public enum Role {
    USER,
    ADMIN
}